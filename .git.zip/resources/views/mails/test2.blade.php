
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<style type="text/css">
body{ background-color: #ffffff;margin: 0px;}
</style>
<body>
    <div class="container">
       <div class="row">
          <div class="col-sm-2"></div>
          <div class="col-sm-8">
          

                <div class="row">
                    <div class="col-sm-4"><img src="{{ asset('image/globallearning.png') }}" style="width:40%;height:80%;;"></div>
                    <div class="col-sm-6"></div>
                    <div class="col-sm-2">
                        <img src="{{ asset('image/facebook.png') }}" style="width:20%;height:8%;">
                        <img src="{{ asset('image/twitter.png') }}" style="width:20%;height:8%;">
                        <img src="{{ asset('image/instagram.png') }}" style="width:20%;height:8%;">
                    
                    </div>
                      
                    
                </div>

                <div class="row">
                   <div class="col-sm-12" style="width:100%;height:40px; background-color:rgb(99, 124, 51);"> </div>
                </div>

                <div class="row">
                    <div class="col-sm-12">
                      <img src="{{ asset('image/people.jpeg') }}" style="width:102%;">
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-12">
                     
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-12">
                      


                        <hr/>
                        <center><p>Global Learning Solution</p></center>
                            <center><p>Wilson Business Park, 2nd floor Block B.<br>
                                Langata Road. P.O Box 856 00606.<br>
                                Nairobi, Kenya<br>
                                Tel: +254 722 791 703<br>
                                info@globallearning.co.ke</p></center>
                                
                        <hr>


                    </div>
                </div>
                   
          </div>
          <div class="col-sm-2"></div>
       </div>

       

    </div>
    
</body>
</html>