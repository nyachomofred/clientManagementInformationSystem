<script>
    window.location.href="http://client.zalegobusiness.com/ClientMis/public/login";
</script>