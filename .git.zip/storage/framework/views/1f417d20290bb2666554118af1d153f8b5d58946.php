<html>
    <head>
        <meta charset="utf-8">
        <title>Chart with VueJS</title>
        <script src=https://cdnjs.cloudflare.com/ajax/libs/echarts/4.0.2/echarts-en.min.js charset=utf-8></script>
    </head>
    <body>
       
        <div id="app">
            <?php echo $chart->container(); ?>

        </div>
        
       
        <?php echo $chart->script(); ?>

    </body>
</html><?php /**PATH /var/www/html/ClientMis/resources/views/charts/index.blade.php ENDPATH**/ ?>