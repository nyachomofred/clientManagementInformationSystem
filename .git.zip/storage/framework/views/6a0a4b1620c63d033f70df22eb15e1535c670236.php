<!DOCTYPE html>
<html>
<head>
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
</style>
</head>
<body>

<table id="customers">
  <tr>
    <th>#</th>
    <th>Message Id</th>
    <th>Subject</th>
    <th>Message</th>
    <th>Date Sent</th>
    <th>Status</th>
    <th>Date Received</th>
  </tr>
  <?php if(!empty($data)): ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
       
        <td><?php echo e(++$key); ?></td>
        <td><?php echo e($record->message_id); ?></td>
        <td><?php echo e($record->subject); ?></td>
        <td><?php echo e($record->message); ?></td>
        <td><?php echo e($record->day); ?> <?php echo e($record->month); ?> <?php echo e($record->year); ?>: <?php echo e($record->dayTime); ?></td>
        <td><span class="label label-success">Received</span></td>
        <td><?php echo e($record->day); ?> <?php echo e($record->month); ?> <?php echo e($record->year); ?>: <?php echo e($record->dayTime); ?></td>
        
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>

</table>

</body>
</html>
<?php /**PATH /var/www/html/ClientMis/resources/views/exports/mailpdf.blade.php ENDPATH**/ ?>