<?php $__env->startSection('content'); ?>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<!-- Main content -->
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


<section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
             
              <form  method="POST" action="<?php echo e(route('reports.clientreport')); ?>">
              <?php echo csrf_field(); ?>
                    <div class="row">

                       <div class="col-sm-2">
                           <label>Membership Type</label>
                            <select name="member_type"class="form-control">
                            <?php if(!empty($data)): ?>
                               <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($record->member_type); ?>"><?php echo e($record->member_type); ?></option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </select>
                       </div>


                       <div class="col-sm-2">
                           <label>Year of admision</label>
                            <select name="year" class="form-control">
                            <?php if(!empty($data)): ?>
                               <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($record->year); ?>"><?php echo e($record->year); ?></option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </select>
                       </div>

                       <div class="col-sm-2">
                           <br>
                            <input type="submit" class="btn btn-primary" value="Filter and Generate Report">
                       </div>


                    </div>
              </form> 
             
            
              
                             
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table  class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Member No</th>
                        <th>Name</th>
                        <th>Membership Type</th>
                        <th>Email</th>
                        <th>Phonenumber</th>
                        <th>City</th>
                        <th>Organisation</th>
                        <th>Job Title</th>
               
                        
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($data)): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($record->member_id); ?></td>
                            <td><?php echo e($record->firstname); ?> <?php echo e($record->lastname); ?></td>
                            <td><?php echo e($record->member_type); ?></td>
                            <td><?php echo e($record->email); ?></td>
                            <td><?php echo e($record->phonenumber); ?></td>
                            <td><?php echo e($record->location); ?></td>                          
                            <td><?php echo e($record->place_of_work); ?></td>
                            <td><?php echo e($record->role); ?></td>
                          
                            
                        </tr>
                       

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
               
              </table>


              <div class="modal fade" id="modal-default">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Add New Member/Client</h4>

                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                            
                        </div>
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('clients.add')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">

                            <div class="form-group">
                                <label class="col-sm-4 control-label">Member No</label>
                                <div class="col-sm-8">
                                    <input type="number" class="form-control" name="member_id" value="<?php echo e(old('member_id')); ?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-4 control-label">Firstname </label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="firstname" placeholder="Delegate Firstname" value="<?php echo e(old('firstname')); ?>" required >
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-4 control-label">Middlename </label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="Middlename" placeholder="Delegate Middlename" value="<?php echo e(old('middlename')); ?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-4 control-label">Lastname</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="lastname" placeholder="Delegate Lastname" value="<?php echo e(old('lastname')); ?>" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-4 control-label">Email Address</label>
                                <div class="col-sm-8">
                                    <input type="" class="form-control" name="email" value="<?php echo e(old('email')); ?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-4 control-label">Membership Type</label>
                                <div class="col-sm-8">
                                   
                                    <select class="form-control" name="member_type" required>
                                        <option value="">Select member type</option>
                                        <option value="Practicing">Practicing</option>
                                        <option value="Associate">Associate</option>
                                        <option value="Fullmember">Fullmember</option>
                                    </select>
                                </div>
                            </div>

                           

                            <div class="form-group">
                                <label class="col-sm-4 control-label">Phonenumber</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="phonenumber" placeholder="eg 2547xxxxxxxxxx" value="<?php echo e(old('phonenumber')); ?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-4 control-label">City</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="location" value="<?php echo e(old('location')); ?>">
                                </div>
                            </div>


                            <div class="form-group">
                                <label class="col-sm-4 control-label">Organisation</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="place_of_work" value="<?php echo e(old('place_of_work')); ?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-4 control-label">Job title</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="role" value="<?php echo e(old('role')); ?>">
                                </div>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                     </form>
                    </div>
                    <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
              </div>
                
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->


    <script type="text/javascript">
        $(document).ready(function() {

          $(".btn-success").click(function(){ 
              var html = $(".clone").html();
              $(".increment").after(html);
          });

          $("body").on("click",".btn-danger",function(){ 
              $(this).parents(".control-group").remove();
          });

        });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ClientMis/resources/views/reports/client.blade.php ENDPATH**/ ?>