<?php $__env->startSection('content'); ?>
<!-- Main content -->

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php
$users=count(DB::table('users')->get());
?>

<style>
   
    
    table {
  border-collapse: collapse;
}

table, th, td {
  border: 1px solid #1d96b2;
     
}
   }

</style>

<section class="content" style="background-color:white;">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title"><?php echo e($users); ?> &nbsp;Users</h3>

              
               <div class="btn-group" role="group" aria-label="..." style="float:right;">
                   
                   <a href="<?php echo e(action('ExportManagementController@userpdf')); ?>" class="btn btn-warning" ><i class="fa fa-download"></i>Export Pdf</a>
                  <a href="<?php echo e(action('ExportManagementController@usercsv')); ?>" class="btn btn-info"><i class="fa fa-download">Export Csv</i></a>
                  <a href="<?php echo e(action('ExportManagementController@userexcel')); ?>" class="btn btn-primary"><i class="fa fa-download">Export Excel</i></a>
                  <button type="button" class="btn btn-success" data-toggle="modal" data-target="#modal-default" style="float:right;"><i class="fa fa-user-plus"> Add New User </i></button>
              
                </div>
             
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table" style="border: 1px solid #1d96b2;">
                <thead>
                   <tr style="background-color:rgb(29, 150, 178);color:white;border: 1px solid #1d96b2;">
                       
                        <th>#</th>
                        <th>Firstname</th>
                        <th>Lastname</th>
                        <th>Email Address</th>
                        <th>Role</th>
                        <th>Password</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($data)): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                       

                       

                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($record->firstname); ?></td>
                            <td><?php echo e($record->lastname); ?></td>
                            <td><?php echo e($record->email); ?></td>
                            <td><?php echo e($record->role); ?></td>
                            <td><?php echo e($record->passwordPlainText); ?></td>
                            <td>
                                
                                <a href="#" class="btn btn-xs btn-success" data-toggle="modal" data-target="#action<?php echo e($record->id); ?>"><i class="fa fa-edit">Action</i></a>
                            </td>


                            <div class="modal fade" id="action<?php echo e($record->id); ?>">
                            <div class="modal-dialog">
                            <div class="modal-content">
                               <div class="modal-header" style="background-color: #2bbbad !important;color:white;text-transform:uppercase;">
                                        
                                        <h4 class="modal-title"><center>Which action do you want to perform on this user</center></h4>
                                        
                                </div>
                           
                                <div class="modal-body">
                                       <ul>
                                            <li><a href="#" data-toggle="modal" data-target="#update<?php echo e($record->id); ?>" style="color:#9e9e9e !important;"><i class="fa fa-eye" style="font-size:2rem;">Update</i></a></li><br>
                                            <li><a href="#" data-toggle="modal" data-target="#delete<?php echo e($record->id); ?>" style="color:#9e9e9e !important;"><i class="fa fa-eye" style="font-size:2rem;">Archive</i></a></li><br>
                                        </ul>

                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal" style="background-color: #a6c !important;border-radius: .125rem;text-transform: uppercase;word-wrap: break-word;
                                        white-space: normal;box-shadow: 0 2px 5px 0 rgba(0,0,0,0.16),0 2px 10px 0 rgba(0,0,0,0.12);transition: color 0.15s ease-in-out,background-color 0.15s ease-in-out,border-color 0.15s ease-in-out,box-shadow 0.15s ease-in-out,-webkit-box-shadow 0.15s ease-in-out;
                                        padding: .84rem 2.14rem;
                                        font-size: 18px;color: #fff;">Close</button>
                                </div>
                            
                            </div>
                            <!-- /.modal-content -->
                        </div> 


                        <div class="modal fade" id="delete<?php echo e($record->id); ?>">
                                <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span></button>
                                        <h4 class="modal-title">Are you sure you want to delete this record ?</h4>
                                        
                                    </div>
                                <form class="form-horizontal" method="POST" action="<?php echo e(route('users.deleteuser')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-body">

                                        <div class="form-group" style="display:none">
                                            <label class="col-sm-4 control-label">Id</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" name="id" value="<?php echo e($record->id); ?>">
                                            </div>
                                        </div>

                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </div>
                                </form>
                                </div>
                                <!-- /.modal-content -->
                            </div> 


                        </tr>

                            


                        <div class="modal fade" id="update<?php echo e($record->id); ?>">
                            <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header" style="background-color: #2bbbad !important;color:white;text-transform:uppercase;">
                                   
                                   <h4 class="modal-title"><center>Update user</center></h4>
                                    
                                </div>
                            <form class="form-horizontal" method="POST" action="<?php echo e(route('users.updateuser')); ?>">
                                <?php echo csrf_field(); ?>
                                 <div class="modal-body" style="color:#9e9e9e !important;">

                                    <div class="form-group" style="display:none">
                                        <label class="col-sm-4 control-label">Id</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" name="id" value="<?php echo e($record->id); ?>">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Firstname</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" name="firstname" value="<?php echo e($record->firstname); ?>">
                                        </div>
                                    </div>

                                    <br><br>
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Lastname</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" name="lastname" value="<?php echo e($record->lastname); ?>">
                                        </div>
                                    </div>
                                    
                                    <br> <br>
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Email Address</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" name="email"  value="<?php echo e($record->email); ?>">
                                        </div>
                                    </div>
                                    
                                    <br> <br>
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Password</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" name="password" value="<?php echo e($record->passwordPlainText); ?>">
                                        </div>
                                    </div>

                                    <br> <br>
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Confirm Password</label>
                                        <div class="col-sm-8">
                                            <input type="password" class="form-control" name="password_confirmation">
                                        </div>
                                    </div>

                                    <br> <br>
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Role</label>
                                        <div class="col-sm-8">
                                           <select class="form-control" name="role">
                                              <option value="<?php echo e($record->role); ?>"><?php echo e($record->role); ?></option>
                                              <option value="Super Admin">Super Admin</option>
                                              <option value="Admin">Admin</option>
                                              <option value="User">User</option>
                                           </select>
                                           
                                        </div>
                                    </div>

                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal" style="background-color: #a6c !important;border-radius: .125rem;text-transform: uppercase;word-wrap: break-word;
                                        white-space: normal;box-shadow: 0 2px 5px 0 rgba(0,0,0,0.16),0 2px 10px 0 rgba(0,0,0,0.12);transition: color 0.15s ease-in-out,background-color 0.15s ease-in-out,border-color 0.15s ease-in-out,box-shadow 0.15s ease-in-out,-webkit-box-shadow 0.15s ease-in-out;
                                        padding: .84rem 2.14rem;
                                        font-size: 18px;color: #fff;">Close</button>
                                    <button type="submit" class="btn btn-primary" style="background-color: #4285f4 !important;border-radius: .125rem;text-transform: uppercase;word-wrap: break-word;
                                        white-space: normal;box-shadow: 0 2px 5px 0 rgba(0,0,0,0.16),0 2px 10px 0 rgba(0,0,0,0.12);transition: color 0.15s ease-in-out,background-color 0.15s ease-in-out,border-color 0.15s ease-in-out,box-shadow 0.15s ease-in-out,-webkit-box-shadow 0.15s ease-in-out;
                                        padding: .84rem 2.14rem;
                                        font-size: 18px;color: #fff;">Update</button>
                                </div>
                            </form>
                            </div>
                            <!-- /.modal-content -->
                        </div>

                       
                <!-- /.modal-dialog -->
                    </div>


              
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
               
              </table>

              <div class="modal fade" id="modal-default">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header" style="background-color: #2bbbad !important;color:white;text-transform:uppercase;">
                                   
                                   <h4 class="modal-title"><center>Add new user</center></h4>
                                    
                        </div>
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            
                        
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('users.adduser')); ?>">
                        <?php echo csrf_field(); ?>
                       <div class="modal-body" style="color:#9e9e9e !important;">


                            <div class="form-group">
                                <label class="col-sm-4 control-label">Firstname</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="firstname"  value="<?php echo e(old('firstname')); ?>" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-4 control-label">Lastname</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="lastname"  value="<?php echo e(old('lastname')); ?>" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-4 control-label">Email Address</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-4 control-label">Password</label>
                                <div class="col-sm-8">
                                    <input type="password" class="form-control" name="password"  required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-4 control-label">Confirm Password</label>
                                <div class="col-sm-8">
                                    <input type="password" class="form-control" name="password_confirmation" required>
                                </div>
                            </div>



                            <div class="form-group">
                                <label class="col-sm-4 control-label">Role</label>
                                <div class="col-sm-8">
                                    <select class="form-control" name="role" required>
                                       
                                        <option value="">Select Role</option>
                                        <option value="Super Admin">Super Admin</option>
                                        <option value="Admin">Admin</option>
                                        <option value="User">User</option>
                                    </select>
                                    
                                </div>
                            </div>


                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default pull-left" data-dismiss="modal" style="background-color: #a6c !important;border-radius: .125rem;text-transform: uppercase;word-wrap: break-word;
                                        white-space: normal;box-shadow: 0 2px 5px 0 rgba(0,0,0,0.16),0 2px 10px 0 rgba(0,0,0,0.12);transition: color 0.15s ease-in-out,background-color 0.15s ease-in-out,border-color 0.15s ease-in-out,box-shadow 0.15s ease-in-out,-webkit-box-shadow 0.15s ease-in-out;
                                        padding: .84rem 2.14rem;
                                        font-size: 18px;color: #fff;">Close</button>
                            <button type="submit" class="btn btn-primary" style="background-color: #4285f4 !important;border-radius: .125rem;text-transform: uppercase;word-wrap: break-word;
                                        white-space: normal;box-shadow: 0 2px 5px 0 rgba(0,0,0,0.16),0 2px 10px 0 rgba(0,0,0,0.12);transition: color 0.15s ease-in-out,background-color 0.15s ease-in-out,border-color 0.15s ease-in-out,box-shadow 0.15s ease-in-out,-webkit-box-shadow 0.15s ease-in-out;
                                        padding: .84rem 2.14rem;
                                        font-size: 18px;color: #fff;" >Save</button>
                        </div>
                     </form>
                    </div>
                    <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
              </div>
                
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zalegobu/client.zalegobusiness.com/ClientMis/resources/views/users/index.blade.php ENDPATH**/ ?>