<script>
    window.location.href="http://zalegoacademy.com/clientmanagementsystem/ClientMis/public/login";
</script><?php /**PATH /home/zalegoa1/public_html/clientmanagementsystem/ClientMis/resources/views/welcome.blade.php ENDPATH**/ ?>