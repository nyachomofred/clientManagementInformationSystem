<?php $__env->startSection('content'); ?>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<?php
$clients=DB::table('clients')->get();
?>
 <!-- Main content -->
 <section class="content">
      <div class="row">
        
        <div class="col-md-12">

        <?php if($errors->any()): ?>
          <div class="alert alert-danger">
              <ul>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
          </div>
      <?php endif; ?>

          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Compose New Message . This message will be received by only selected people</h3>
            </div>
                <form method="POST" action="<?php echo e(route('mails.createbarner')); ?>" enctype="multipart/form-data" class="form-horizontal">
                <?php echo csrf_field(); ?>
                    <!-- /.box-header -->
                    <div class="box-body">

                    <div class="form-group">
                       <label class="col-sm-2 control-label">Select Recipient</label>
                       <div class="col-sm-10">

                        <select class="form-control select2" multiple="multiple" data-placeholder="Email" style="width: 100%;" name="email[]"> 
                        <?php if(!empty($clients)): ?>
                          <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($client->email); ?>"><?php echo e($client->firstname); ?> <?php echo e($client->lastname); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </select>
                        </div>

                      </div>

                      <br>

                      <div class="form-group">
                          <label class="col-sm-2 control-label">Subject</label>
                          <div class="col-sm-10">
                            <input class="form-control" placeholder="Subject:" name="subject">
                          </div>
                      </div>

                     <br>

                      

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Attachment berner Immage</label>
                         <div class="col-sm-10">
                            <div class="input-group control-group increment" >
                                <input type="file" name="a_file[]" class="form-control" multiple>
                                <div class="input-group-btn"> 
                                  <button class="btn btn-success" type="button"><i class="glyphicon glyphicon-plus"></i>Add</button>
                                </div>
                              </div>
                              <div class="clone hide">
                                <div class="control-group input-group" style="margin-top:10px">
                                  <input type="file" name="a_file[]" class="form-control" multiple>
                                  <div class="input-group-btn"> 
                                    <button class="btn btn-danger" type="button"><i class="glyphicon glyphicon-remove"></i> Remove</button>
                                  </div>
                                </div>
                              </div>
                      </div>
                      </div>

                    </div>
                    
                    <!-- /.box-body -->
                    <div class="box-footer">
                      <div class="pull-right">
                        <button type="submit" class="btn btn-primary"><i class="fa fa-envelope-o"></i> Send</button>
                      </div>
                      <a href="<?php echo e(route('mails.index')); ?>" class="btn btn-default"><i class="fa fa-times"></i> Discard</a>
                    </div>
                </form>
            <!-- /.box-footer -->
          </div>
          <!-- /. box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>

    <script type="text/javascript">
        $(document).ready(function() {

          $(".btn-success").click(function(){ 
              var html = $(".clone").html();
              $(".increment").after(html);
          });

          $("body").on("click",".btn-danger",function(){ 
              $(this).parents(".control-group").remove();
          });

        });
</script>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ClientMis/resources/views/mails/barner.blade.php ENDPATH**/ ?>