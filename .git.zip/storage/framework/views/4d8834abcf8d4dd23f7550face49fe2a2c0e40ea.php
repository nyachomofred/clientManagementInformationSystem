<?php $__env->startSection('content'); ?>
<!-- Main content -->
<section class="content">
      <div class="row">
        <div class="col-md-3">
         
        <div class="btn-group">
            <button type="button" class="btn btn-primary" style="width:265px;">Compose Message</button>
            <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
              <span class="caret"></span>
              <span class="sr-only">Toggle Dropdown</span>
            </button>
            <ul class="dropdown-menu" role="menu">
                
              <li><a href="<?php echo e(route('mails.composeToAllMember')); ?>"><i class="fa fa-file-text-o"></i>Compose email to all members</a></li>
              <li><a href="<?php echo e(route('mails.composeToAssociateMember')); ?>"><i class="fa fa-file-text-o"></i>Compose email to associate members</a></li>
              <li><a href="<?php echo e(route('mails.composeToFullMember')); ?>"><i class="fa fa-file-text-o"></i>Compose email full Members</a></li>
              <li><a href="<?php echo e(route('mails.composeToPracticingMember')); ?>"><i class="fa fa-file-text-o"></i>Compose email to Practicing Members</a></li>
              <li><a href="<?php echo e(route('mails.compose')); ?>"><i class="fa fa-file-text-o"></i> Compos email to specific members</a></li>
            </ul>
          </div>
          <br><br>


          <div class="box box-solid">
            <div class="box-header with-border">
              <h3 class="box-title">Folders</h3>

              <div class="box-tools">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
              </div>
            </div>
            <div class="box-body no-padding">
              <ul class="nav nav-pills nav-stacked">
                
                  <li><a href="<?php echo e(route('mails.sent')); ?>"><i class="fa fa-envelope-o"></i> Sent</a></li>
                <li><a href="<?php echo e(route('mails.index')); ?>"><i class="fa fa-file-text-o"></i> Drafts</a></li>
              </ul>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /. box -->
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Sent Mails</h3>

              <div class="box-tools pull-right">
                <div class="has-feedback">
                  <input type="text" class="form-control input-sm" placeholder="Search Mail">
                  <span class="glyphicon glyphicon-search form-control-feedback"></span>
                </div>
              </div>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body no-padding">
             
              <div class="table-responsive mailbox-messages">
              <?php if(!empty($sentmails)): ?>
                <table class="table table-hover table-striped">
                  <tbody>
                  <?php $__currentLoopData = $sentmails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><input type="checkbox"></td>
                      <td class="mailbox-star"><a href="#"><i class="fa fa-star text-yellow"></i></a></td>
                      <td class="mailbox-name"><a href="<?php echo e(url('/mails/readSentMails/'.$record->message_id)); ?>"><?php echo e($record->firstname); ?><?php echo e($record->lastname); ?></a></td>
                      <td class="mailbox-subject"><b><?php echo e($record->subject); ?></b> - Trying to find a solution to this problem...
                      </td>
                      <td class="mailbox-attachment"><i class="fa fa-paperclip"></i></td>
                      <td class="mailbox-date"><?php echo e($record->day); ?>/<?php echo e($record->month); ?>/<?php echo e($record->year); ?> <?php echo e($record->dayTime); ?></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
                <?php else: ?>
                No sent mails. To send an emails go to compose section.
                <?php endif; ?>
                <!-- /.table -->
              </div>
              <!-- /.mail-box-messages -->
            </div>
            <!-- /.box-body -->
            <div class="box-footer no-padding">
             
            </div>
          </div>
          <!-- /. box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ClientMis/resources/views/mails/sent.blade.php ENDPATH**/ ?>