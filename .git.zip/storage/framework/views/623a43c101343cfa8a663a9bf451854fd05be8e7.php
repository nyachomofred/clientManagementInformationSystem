<?php $__env->startSection('content'); ?>
<?php
$data=DB::table('files')->orderBy('id','DESC')->first();
$file=$data->file;
$path='image/'.$file;

?>

	<?php echo $__env->make('beautymail::templates.widgets.articleStart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		
       <h2>Subject: <?php echo e($subject); ?></h2>
	  
	   
	  
	   <a href="http://www.maseno.com"><img src="<?php echo e($message->embed($path)); ?>" style="width:100%;height:600px;"></a>
	  
	<?php echo $__env->make('beautymail::templates.widgets.articleEnd', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('beautymail::templates.widgets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ClientMis/resources/views/emails/barner.blade.php ENDPATH**/ ?>