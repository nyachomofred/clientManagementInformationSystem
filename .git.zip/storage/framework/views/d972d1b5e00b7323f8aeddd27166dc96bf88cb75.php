<?php $__env->startSection('content'); ?>



<section class="content">
    <div class="row">
       <div class="box">
          <div class="box-header"></div>
          <div class="row">

            <div class="col-sm-1"></div>
             <div class="col-sm-10">
                    <div class="box">
                        <div class="box-header">Company Profile
                            <button type="button" class="btn btn-success" data-toggle="modal" data-target="#modal-default" style="float:right;"><i class="fa fa-user-plus"> Update Company Profile </i></button>
                        </div>
                       <?php if(!empty($data)): ?>
                       <table class="table" style="width:100%">
                            <tr>
                                <td>
                                
                                <img src="<?php echo e(asset('image/'.$data->companyLogo)); ?>" class="img-circle" style="width:60%"><br>
                                <a href="#" class="btn btn-link" data-toggle="modal" data-target="#modal-logo"> Update Company Logo </a>
                                
                                </td>
                                <td>
                                    <table class="table table-striped" style="height:300px;">
                                        <tr>
                                            <td>Compamny Name</td>
                                            <td><?php echo e($data->companyName); ?></td>
                                        </tr>

                                        <tr>
                                            <td>Telephone Number</td>
                                            <td><?php echo e($data->companyTelNo); ?></td>
                                        </tr>


                                        <tr>
                                            <td>Company Email</td>
                                            <td><?php echo e($data->companyEmail); ?></td>
                                        </tr>

                                        <tr>
                                            <td>Company Website</td>
                                            <td><?php echo e($data->companyWebsiteLink); ?></td>
                                        </tr>

                                    </table>
                                </td>
                            </tr>
                        </table>
                       <?php endif; ?>
                    </div>



                <div class="modal fade" id="modal-logo">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title">Update Company Logo</h4>


                            </div>
                        <?php if(!empty($data)): ?>
                        <form class="form-horizontal" method="POST" action="<?php echo e(route('signatures.updatelogo')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="modal-body">

                            

                                <div class="form-group" style="display:none;">
                                    <label class="col-sm-4 control-label">ID </label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="id"  value="<?php echo e($data->id); ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-sm-4 control-label">Attach New Logo Image </label>
                                    <div class="col-sm-8">
                                        <input type="file" class="form-control" name="companyLogo" required>
                                    </div>
                                </div>

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-info pull-left" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                        </form>
                        <?php endif; ?>
                        </div>
                        <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                </div>


                
                </div>


             <div class="modal fade" id="modal-default">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Add New Member/Client</h4>

                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                        </div>
                    <?php if(!empty($data)): ?>
                     <form class="form-horizontal" method="POST" action="<?php echo e(route('signatures.update')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">

                           

                            <div class="form-group" style="display:none;">
                                <label class="col-sm-4 control-label">ID </label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="id"  value="<?php echo e($data->id); ?>">
                                </div>
                            </div>



                            <div class="form-group">
                                <label class="col-sm-4 control-label">Company Name </label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="companyName" value="<?php echo e($data->companyName); ?>" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-4 control-label">company Telephone No</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="companyTelNo"  value="<?php echo e($data->companyTelNo); ?>" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-4 control-label">Company Email Address</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="companyEmail" value="<?php echo e($data->companyEmail); ?>">
                                </div>
                            </div>

                           

                            <div class="form-group">
                                <label class="col-sm-4 control-label">Company Website Link</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" name="companyWebsiteLink"  value="<?php echo e($data->companyWebsiteLink); ?>">
                                </div>
                            </div>

                           

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-info pull-left" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                     </form>
                    <?php endif; ?>
                    </div>
                    <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
              </div>


             
             </div>

             <div class="col-sm-1"></div>
          </div>
       </div>
    </div>
     
</section>
    <!-- /.content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zalegobu/client.zalegobusiness.com/ClientMis/resources/views/signatures/index.blade.php ENDPATH**/ ?>