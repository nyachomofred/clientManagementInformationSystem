<?php $__env->startSection('content'); ?>

            <div class="col-xs-12 text-center login-box-msg">
              <img src="<?php echo e(asset('resources/assets/logo/logo.png')); ?>" height="100" alt="Logo" class="rounded-circle">
            </div>
            <h4 class="login-box-msg">Register a new account</h4>
           <br/>

    <form method="POST" action="<?php echo e(route('register')); ?>" >
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group has-feedback ">
                    <input id="name" type="text" class="form-control<?php echo e($errors->has('firstname') ? ' is-invalid' : ''); ?>" name="firstname" value="<?php echo e(old('firstname')); ?>" required autofocus placeholder="First Name" />

                     <?php if($errors->has('firstname')): ?>
                     <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('firstname')); ?></strong>
                     </span>
                      <?php endif; ?>
                                  
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group has-feedback ">
                    <input id="name" type="text" class="form-control<?php echo e($errors->has('lastname') ? ' is-invalid' : ''); ?>" name="lastname" value="<?php echo e(old('lastname')); ?>" required autofocus placeholder="Last Name" />

                     <?php if($errors->has('lastname')): ?>
                     <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('lastname')); ?></strong>
                     </span>
                      <?php endif; ?>
                                  
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="form-group has-feedback ">
                    <input  id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required placeholder="Email" />
                    <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback" role="alert">
                       <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                    <?php endif; ?>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group has-feedback ">
                    <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required placeholder="Password" />

                    <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                    <?php endif; ?>
                                    </div>
            </div>
            <div class="col-md-6">
                <div class="form-group has-feedback ">
                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required placeholder="Retype Password" />

                                    </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 col-md-offset-3 offset-md-3 my-3">
                <button type="submit"
                        class="btn bg-olive btn-block">Register</button>
            </div>
        </div>
    </form>
    <br/>
    <div class="row">
        <div class="col-md-6 col-md-offset-3 offset-md-3 my-3 text-center">
            <a class="" href="<?php echo e(route('login')); ?>">Already have an account</a><br/><br/>
        </div>
    </div>
    </div>
    <!-- /.login-box-body -->
</div>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ClientMis/resources/views/auth/register.blade.php ENDPATH**/ ?>