<?php $__env->startSection('content'); ?>
<!-- Main content -->
<section class="content">
      <div class="row">
     
        <!-- /.col -->
        <div class="col-md-12">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">
              <a href="<?php echo e(route('messages.inbox')); ?>"><i class="fa fa-backward">Go Back</i></a>
                &nbsp; &nbsp; &nbsp; Read Message
              
              </h3>
              <div class="box-tools pull-right">
                <a href="#" class="btn btn-box-tool" data-toggle="tooltip" title="Previous"><i class="fa fa-chevron-left"></i></a>
                <a href="#" class="btn btn-box-tool" data-toggle="tooltip" title="Next"><i class="fa fa-chevron-right"></i></a>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body no-padding">
              <div class="mailbox-read-info">
               <?php if(!empty($sms)): ?>
                <h3>Subject : <?php echo e($sms->subject); ?></h3>
                <h5>
                  <span class="mailbox-read-time pull-right"><?php echo e($sms->day); ?>/<?php echo e($sms->month); ?>/<?php echo e($sms->year); ?> <?php echo e($sms->dayTime); ?></span></h5>
               <?php endif; ?>
              </div>
              <!-- /.mailbox-read-info -->
              
              <!-- /.mailbox-controls -->
              <div class="mailbox-read-message">
                <h3>Message</h3>
                <?php if(!empty($sms)): ?>
                   <p><?php echo e($sms->message); ?></p>
                <?php endif; ?>
              
              </div>
              <!-- /.mailbox-read-message -->
            </div>
            <!-- /.box-body -->
            <div class="box-footer">
              <h3>Recipient</h3>
              <?php if(!empty($ccsms)): ?>
              <table class="table">
                <thead>
                   <tr>
                     <th>#</th>
                     <th>Name</th>
                     <th>phonenumber</th>
                   </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $ccsms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                     <td><?php echo e(++$key); ?></td>
                     <td><?php echo e($record->firstname); ?> <?php echo e($record->lastname); ?></td>
                     <td><?php echo e($record->phonenumber); ?></td>
                   </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              <?php endif; ?>
            </div>
            
          </div>
          <!-- /. box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zalegobu/client.zalegobusiness.com/ClientMis/resources/views/messages/readmessage.blade.php ENDPATH**/ ?>