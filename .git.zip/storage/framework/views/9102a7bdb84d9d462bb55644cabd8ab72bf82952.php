<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<?php 
$registeredusers=count(DB::table('users')->get());
$registeredclients=count(DB::table('clients')->get());
?>
  
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Client Management | Information System</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo e(asset('master/bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('master/bower_components/font-awesome/css/font-awesome.min.css')); ?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo e(asset('master/bower_components/Ionicons/css/ionicons.min.css')); ?>">
  <!-- daterange picker -->
  <link rel="stylesheet" href="<?php echo e(asset('master/bower_components/bootstrap-daterangepicker/daterangepicker.css')); ?>">
  <!-- bootstrap datepicker -->
  <link rel="stylesheet" href="<?php echo e(asset('master/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
  <!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="<?php echo e(asset('master/plugins/iCheck/all.css')); ?>">
  <!-- Bootstrap Color Picker -->
  <link rel="stylesheet" href="<?php echo e(asset('master/bower_components/bootstrap-colorpicker/dist/css/bootstrap-colorpicker.min.css')); ?>">
  <!-- Bootstrap time Picker -->
  <link rel="stylesheet" href="<?php echo e(asset('master/plugins/timepicker/bootstrap-timepicker.min.css')); ?>">
  <!-- Select2 -->
  <link rel="stylesheet" href="<?php echo e(asset('master/bower_components/select2/dist/css/select2.min.css')); ?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(asset('master/dist/css/AdminLTE.min.css')); ?>">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo e(asset('master/dist/css/skins/_all-skins.min.css')); ?>">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(asset('master/plugins/datatables/dataTables.bootstrap4.css')); ?>">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="<?php echo e(asset('master/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css')); ?>">
  <!-- Theme style -->
  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="<?php echo e(route('home')); ?>" class="logo">
      
      <span class="logo-lg"><b>Client </b>MIS</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="<?php echo e(route('home')); ?>" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="<?php echo e(asset('profile/user.svg')); ?>" class="user-image" alt="User Image">
              <?php if(auth()->guard()->guest()): ?>
              <span class="hidden-xs">System Administrator</span>
              <?php else: ?>
              <span class="hidden-xs"><?php echo e(Auth::user()->firstname); ?> <?php echo e(Auth::user()->lastname); ?></span>
              <?php endif; ?>

             
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="<?php echo e(asset('profile/user.svg')); ?>" class="img-circle" alt="User Image">

                <p>
                <?php if(auth()->guard()->guest()): ?>
                <?php else: ?>
                   <?php echo e(Auth::user()->firstname); ?> <?php echo e(Auth::user()->firstname); ?> - System Administrator
                <?php endif; ?>
  
                </p>
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="<?php echo e(route('profiles.index')); ?>" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                 
                  <a class="btn btn-default btn-flat" href="<?php echo e(route('logout')); ?>"
                          onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                          <?php echo e(__('Sign Out')); ?>

                      </a>

                      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                          <?php echo csrf_field(); ?>
                      </form>

                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
         
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(asset('profile/user.svg')); ?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
        <?php if(auth()->guard()->guest()): ?>
        <?php else: ?>
        <p><?php echo e(Auth::user()->firstname); ?> <?php echo e(Auth::user()->firstname); ?></p>
        <?php endif; ?>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- search form -->
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
          <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>

        <li>
          <a href="<?php echo e(route('home')); ?>">
            <i class="fa fa-home"></i> <span>Home</span>
            
          </a>
        </li>

        <li>
          <a href="<?php echo e(route('mails.test')); ?>">
            <i class="fa fa-home"></i> <span>mail template</span>
            
          </a>
        </li>



        <li>
          <a href="<?php echo e(route('signatures.index')); ?>">
            <i class="fa fa-home"></i> <span>Company Profile</span>
            
          </a>
        </li>
       
        <li>
          <a href="<?php echo e(route('profiles.index')); ?>">
            <i class="fa fa-user"></i> <span>Profile</span>
            
          </a>
        </li>

        <li>
          <a href="<?php echo e(route('users.index')); ?>">
            <i class="fa fa-users"></i> <span>Users</span>
            <span class="pull-right-container">
            <?php if(!empty($registeredusers)): ?>
               <small class="label pull-right bg-red"><?php echo e($registeredusers); ?></small>
            <?php else: ?>
            <small class="label pull-right bg-red">0</small>
            <?php endif; ?>
            </span>
          </a>
        </li>

        <li>
          <a href="<?php echo e(route('clients.index')); ?>">
            <i class="fa fa-users"></i> <span>Clients Management</span>
            <span class="pull-right-container">
            <?php if(!empty($registeredclients)): ?>
            <small class="label pull-right bg-green"><?php echo e($registeredclients); ?></small>
            <?php else: ?>
            <small class="label pull-right bg-green">0</small>
            <?php endif; ?>
             
            </span>
          </a>
        </li>
        
        
        
        <li class="treeview">
          <a href="#">
            <i class="fa fa-envelope"></i>
            <span>Group Mails</span>
            <span class="pull-right-container">
              <span class="label label-primary pull-right"></span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(route('mails.index')); ?>"><i class="fa fa-file-text-o"></i>View Sent Mails</a></li>
            <li><a href="<?php echo e(route('mails.composeToAllMember')); ?>"><i class="fa fa-file-text-o"></i>Mail   all Members</a></li>
            <li><a href="<?php echo e(route('mails.composeToAssociateMember')); ?>"><i class="fa fa-file-text-o"></i>Mail associate members only</a></li>
            <li><a href="<?php echo e(route('mails.composeToFullMember')); ?>"><i class="fa fa-file-text-o"></i>Mail full Members Only</a></li>
            <li><a href="<?php echo e(route('mails.composeToPracticingMember')); ?>"><i class="fa fa-file-text-o"></i>Mail Practicing Members Only</a></li>
            <li><a href="<?php echo e(route('mails.compose')); ?>"><i class="fa fa-file-text-o"></i>Mail specific members</a></li>
           
          </ul>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-envelope"></i>
            <span>Mails Campaign</span>
            <span class="pull-right-container">
              <span class="label label-primary pull-right"></span>
            </span>
          </a>
          <ul class="treeview-menu">
           
            <li><a href="<?php echo e(route('mails.barner')); ?>"><i class="fa fa-file-text-o"></i>Activation Mail</a></li>
            <li><a href="<?php echo e(route('mails.poster')); ?>"><i class="fa fa-file-text-o"></i>Advertisement</a></li>
            
          </ul>
        </li>


        <li class="treeview">
          <a href="#">
            <i class="fa fa-envelope"></i>
            <span>Group Messages</span>
            <span class="pull-right-container">
              <span class="label label-primary pull-right"></span>
            </span>
          </a>
          <ul class="treeview-menu">
           <li><a href="<?php echo e(route('messages.inbox')); ?>"><i class="fa fa-file-text-o"></i>View Sent Mails</a></li>
           
            <li><a href="<?php echo e(route('messages.composespecificgroup')); ?>"><i class="fa fa-file-text-o"></i>Message specific people</a></li>
            <li><a href="<?php echo e(route('messages.composepracticingmember')); ?>"><i class="fa fa-file-text-o"></i>  Message  Practicing Members</a></li>
            <li><a href="<?php echo e(route('messages.composefullmember')); ?>"><i class="fa fa-file-text-o"></i>Message  Fullmembers</a></li>
            <li><a href="<?php echo e(route('messages.composeassociatemember')); ?>"><i class="fa fa-file-text-o"></i>Message Associate Members</a></li>
            <li><a href="<?php echo e(route('messages.composeToAll')); ?>"><i class="fa fa-file-text-o"></i> Message  all Members</a></li>
            <li><a href="<?php echo e(route('messages.draftmessage')); ?>"><i class="fa fa-file-text-o"></i>Draft Message</a></li>
          </ul>
        </li>



        <li class="treeview">
          <a href="#">
            <i class="fa fa-envelope"></i>
            <span>Reports</span>
            <span class="pull-right-container">
              <span class="label label-primary pull-right">5</span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(route('reports.client')); ?>"><i class="fa fa-file-text-o"></i> Members and their memberships</a></li>
            <li><a href="#"><i class="fa fa-file-text-o"></i>Send and failed mails</a></li>
            <li><a href="#"><i class="fa fa-file-text-o"></i> Send and Failed messages</a></li>
            <li><a href="#"><i class="fa fa-file-text-o"></i>Send and processed invoices</a></li>
          </ul>
        </li>

        <li>
        <a  href="<?php echo e(route('logout')); ?>"
                          onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                          <i class="fa fa-share"></i> <span>Log Out</span>

                      </a>

           <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">  <?php echo csrf_field(); ?></form>
        </li>



      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Client Management Information System
       
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">dashboard</a></li>
        <li class="active">Client Management Information System</li>
      </ol>
    </section>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 2.4.13
    </div>
    <strong>Copyright &copy; 2019 <a href="https://zalegoinstitute.ac.ke">Zalego Institute Of Technology And Innovation</a>.</strong> All rights
    reserved.
  </footer>

</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo e(asset('master/bower_components/jquery/dist/jquery.min.js')); ?>"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo e(asset('master/bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
<!-- Select2 -->
<script src="<?php echo e(asset('master/bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>
<!-- InputMask -->
<script src="<?php echo e(asset('master/plugins/input-mask/jquery.inputmask.js')); ?>"></script>
<script src="<?php echo e(asset('master/plugins/input-mask/jquery.inputmask.date.extensions.js')); ?>"></script>
<script src="<?php echo e(asset('master/plugins/input-mask/jquery.inputmask.extensions.js')); ?>"></script>
<!-- date-range-picker -->
<script src="<?php echo e(asset('master/bower_components/moment/min/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('master/bower_components/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
<!-- bootstrap datepicker -->
<script src="<?php echo e(asset('master/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
<!-- bootstrap color picker -->
<script src="<?php echo e(asset('master/bower_components/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js')); ?>"></script>
<!-- bootstrap time picker -->
<script src="<?php echo e(asset('master/plugins/timepicker/bootstrap-timepicker.min.js')); ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo e(asset('master/bower_components/jquery-slimscroll/jquery.slimscroll.min.js')); ?>"></script>
<!-- iCheck 1.0.1 -->
<script src="<?php echo e(asset('master/plugins/iCheck/icheck.min.js')); ?>"></script>
<!-- FastClick -->
<script src="<?php echo e(asset('master/bower_components/fastclick/lib/fastclick.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('master/dist/js/adminlte.min.js')); ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e(asset('master/dist/js/demo.js')); ?>"></script>
<!-- DataTables -->
<script src="<?php echo e(asset('master/plugins/datatables/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(asset('master/plugins/datatables/dataTables.bootstrap4.js')); ?>"></script>
<script src="<?php echo e(asset('master/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js')); ?>"></script>

<script src="<?php echo e(asset('master/bower_components/ckeditor/ckeditor.js')); ?>"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="<?php echo e(asset('master/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js')); ?>"></script>
<!-- Page Script -->
<!-- Page script -->
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Datemask dd/mm/yyyy
    $('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
    //Datemask2 mm/dd/yyyy
    $('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
    //Money Euro
    $('[data-mask]').inputmask()

    //Date range picker
    $('#reservation').daterangepicker()
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({ timePicker: true, timePickerIncrement: 30, locale: { format: 'MM/DD/YYYY hh:mm A' }})
    //Date range as a button
    $('#daterange-btn').daterangepicker(
      {
        ranges   : {
          'Today'       : [moment(), moment()],
          'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month'  : [moment().startOf('month'), moment().endOf('month')],
          'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        startDate: moment().subtract(29, 'days'),
        endDate  : moment()
      },
      function (start, end) {
        $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
      }
    )

    //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    })

    //iCheck for checkbox and radio inputs
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass   : 'iradio_minimal-blue'
    })
    //Red color scheme for iCheck
    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
      checkboxClass: 'icheckbox_minimal-red',
      radioClass   : 'iradio_minimal-red'
    })
    //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass   : 'iradio_flat-green'
    })

    //Colorpicker
    $('.my-colorpicker1').colorpicker()
    //color picker with addon
    $('.my-colorpicker2').colorpicker()

    //Timepicker
    $('.timepicker').timepicker({
      showInputs: false
    })
  })
</script>
<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });
  });
</script>

<script>
  $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('editor1')
    //bootstrap WYSIHTML5 - text editor
    $('.textarea').wysihtml5()
  })
</script>




</body>
</html>
<?php /**PATH /var/www/html/ClientMis/resources/views/layouts/master.blade.php ENDPATH**/ ?>