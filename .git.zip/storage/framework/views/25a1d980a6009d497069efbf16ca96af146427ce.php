<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php
$draft=count(DB::table('drafts')->get());
$clients=DB::table('clients')->get();
?>
<!-- Main content -->
<section class="content">
      <div class="row">
        
        <div class="col-md-12">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title"><?php echo e($draft); ?> Draft Messages</h3>
                  <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#modal-default" style="float:right;">Draft New Message</a>
              <div class="box-tools pull-right">
                <div class="has-feedback">
                 
                </div>
              </div>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body no-padding">
              <div class="mailbox-controls">
               
              </div>
              <div class="table-responsive mailbox-messages">
                <table class="table table-hover table-striped" id="example1">

                <thead>
                    <tr>
                       
                        <th>#</th>
                        <th>Subject</th>
                        <th>Message</th>
                        <th>Date Created</th>
                        <th>Action</th>
                        
                    </tr>
                </thead>

                  <tbody>
                  <?php if(!empty($data)): ?>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e(++$key); ?></td>
                    <td><?php echo e($record->subject); ?></td>
                    <td><?php echo e($record->message); ?></td>
                    <td class="mailbox-date"><?php echo e($record->day); ?>/<?php echo e($record->month); ?>/<?php echo e($record->year); ?> <?php echo e($record->dayTime); ?></td>

                    <td>
                        <div class="margin">
                            <div class="btn-group">
                                <button type="button" class="btn btn-default">Action</button>
                                <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                                    <span class="caret"></span>
                                    <span class="sr-only">Toggle Dropdown</span>
                                </button>
                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="#" data-toggle="modal" data-target="#send<?php echo e($record->id); ?>"><i class="fa fa-trash">Send message</i></a></li>
                                    <li><a href="#" data-toggle="modal" data-target="#update<?php echo e($record->id); ?>"><i class="fa fa-eye">Update</i></a></li>
                                    <li><a href="#" data-toggle="modal" data-target="#delete<?php echo e($record->id); ?>"><i class="fa fa-trash">Delete</i></a></li>
                                </ul>
                            </div>

                        </div>
                    </td>

                  </tr>

                  <div class="modal fade" id="send<?php echo e($record->id); ?>">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Send message</h4>
                        </div>
                     <form class="form-horizontal" method="POST" action="<?php echo e(route('messages.sendToSpecific')); ?>">
                         <?php echo csrf_field(); ?>
                            <div class="modal-body">

                                <div class="form-group">
                                    <label for="inputEmail3" class="col-sm-2 control-label">Select recipient</label>
                                    <div class="col-sm-10">
                                    
                                    <select class="form-control select2" multiple="multiple" data-placeholder="To" style="width: 100%;" name="phonenumbers[]" required>
                                        <?php if(!empty($clients)): ?>
                                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($client->phonenumber); ?>"><?php echo e($client->firstname); ?> <?php echo e($client->lastname); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>

                                    </div>
                                </div>

                            <br><br>

                            <div class="form-group">
                                <label for="inputEmail3" class="col-sm-2 control-label">Subject</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="subject" required   value="<?php echo e($record->subject); ?>">
                                </div>
                            </div>
                            <br><br>

                            <div class="form-group">
                                <label for="inputEmail3" class="col-sm-2 control-label">Message</label>
                                <div class="col-sm-10">
                                   <textarea name="message" class="form-control" required ><?php echo e($record->message); ?></textarea>
                                </div>
                            </div>
    
                            <br><br>
                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Send</button>
                            </div>
                      </form>
                        </div>
                        <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                 </div>


                 <div class="modal fade" id="update<?php echo e($record->id); ?>">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Update Message</h4>
                        </div>
                     <form class="form-horizontal" method="POST" action="<?php echo e(route('messages.updateDraftMessage')); ?>">
                         <?php echo csrf_field(); ?>
                            <div class="modal-body">


                            <div class="form-group" style="display:none">
                                <label for="inputEmail3" class="col-sm-2 control-label">Id</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="id" value="<?php echo e($record->id); ?>">
                                </div>
                            </div>


                            <div class="form-group">
                                <label for="inputEmail3" class="col-sm-2 control-label">Subject</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="subject" required   value="<?php echo e($record->subject); ?>">
                                </div>
                            </div>
                            <br><br>

                            <div class="form-group">
                                <label for="inputEmail3" class="col-sm-2 control-label">Message</label>
                                <div class="col-sm-10">
                                   <textarea name="message" class="form-control" required ><?php echo e($record->message); ?></textarea>
                                </div>
                            </div>
    
                            <br><br>
                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Save</button>
                            </div>
                      </form>
                        </div>
                        <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                 </div>




                  <div class="modal fade" id="delete<?php echo e($record->id); ?>">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Are you sure you want to delete this record</h4>
                        </div>
                     <form class="form-horizontal" method="POST" action="<?php echo e(route('messages.deleteDraftMessage')); ?>">
                         <?php echo csrf_field(); ?>
                            <div class="modal-body">

                            <div class="form-group" style="display:none">
                                <label for="inputEmail3" class="col-sm-2 control-label">Id</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="id" value="<?php echo e($record->id); ?>">
                                </div>
                            </div>

                            
                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </div>
                      </form>
                        </div>
                        <!-- /.modal-content -->
                    </div>
                <!-- /.modal-dialog -->
                </div>


                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                  </tbody>
                </table>
                <!-- /.table -->
              </div>
              <!-- /.mail-box-messages -->
            </div>
            <!-- /.box-body -->
            <div class="box-footer no-padding">
                <div class="modal fade" id="modal-default">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Draft New Message</h4>
                        </div>
                     <form class="form-horizontal" method="POST" action="<?php echo e(route('messages.saveDraftMessage')); ?>">
                         <?php echo csrf_field(); ?>
                            <div class="modal-body">

                            <div class="form-group">
                                <label for="inputEmail3" class="col-sm-2 control-label">Subject</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="subject" id="inputEmail3" placeholder="Enter Subject" value="<?php echo e(old('subject')); ?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputEmail3" class="col-sm-2 control-label">Message</label>
                                <div class="col-sm-10">
                                   <textarea name="message" class="form-control" required value="<?php echo e(old('message')); ?>"></textarea>
                                </div>
                            </div>
    
                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Save</button>
                            </div>
                      </form>
                        </div>
                        <!-- /.modal-content -->
                    </div>
                <!-- /.modal-dialog -->
                </div>
            </div>
          </div>
          <!-- /. box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zalegobu/client.zalegobusiness.com/ClientMis/resources/views/messages/draftmessage.blade.php ENDPATH**/ ?>