<script>
    window.location.href="http://client.zalegobusiness.com/ClientMis/public/login";
</script><?php /**PATH /home/zalegobu/client.zalegobusiness.com/ClientMis/resources/views/welcome.blade.php ENDPATH**/ ?>