<?php $__env->startSection('content'); ?>
<?php
$fullmembers=count(DB::table('clients')->get());
$data=DB::table('clients')->get();

?>
<!-- Main content -->
<section class="content">
      <div class="row">
        <div class="col-md-3">
          
           <div class="btn-group">
                  <button type="button" class="btn btn-primary" style="width:265px;">Compose Message</button>
                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                    <span class="caret"></span>
                    <span class="sr-only">Toggle Dropdown</span>
                  </button>
                  <ul class="dropdown-menu" role="menu">
                      
                    <li><a href="<?php echo e(route('messages.composespecificgroup')); ?>"><i class="fa fa-file-text-o"></i>Compose Message to specific people</a></li>
                    <li><a href="<?php echo e(route('messages.composepracticingmember')); ?>"><i class="fa fa-file-text-o"></i> Compos Message to Practicing Members</a></li>
                    <li><a href="<?php echo e(route('messages.composefullmember')); ?>"><i class="fa fa-file-text-o"></i>Compose Message to  Fullmembers</a></li>
                    <li><a href="<?php echo e(route('messages.composeassociatemember')); ?>"><i class="fa fa-file-text-o"></i>Compose Message to Associate Members</a></li>
                    <li><a href="<?php echo e(route('messages.composeToAll')); ?>"><i class="fa fa-file-text-o"></i>Compose Message to all Members</a></li>
                    
                  </ul>
            </div>
            <br><br>

          <div class="box box-solid">
            <div class="box-header with-border">
              <h3 class="box-title">Folders</h3>

              <div class="box-tools">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
              </div>
            </div>
            <div class="box-body no-padding">
              <ul class="nav nav-pills nav-stacked">
                <li><a href="<?php echo e(route('messages.inbox')); ?>"><i class="fa fa-envelope-o"></i> Sent Messages</a></li>
                <li><a href="<?php echo e(route('messages.draftmessage')); ?>"><i class="fa fa-file-text-o"></i> Drafts Messages</a></li>             
              </ul>
            </div>
            <!-- /.box-body -->
          </div>
         
        </div>
        <!-- /.col -->
        <div class="col-md-9">

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Compose New Message [This message shall be received by <?php echo e($fullmembers); ?>  members] <a href="#" class="btn btn-link" data-toggle="modal" data-target="#modal-default">View Recipient</a></h3>

            </div>
            <form method="POST" action="<?php echo e(route('messages.sendToAllMember')); ?>">
           <?php echo csrf_field(); ?>
            <div class="box-body">
              <div class="form-group">
                <input class="form-control" placeholder="Subject:" name="subject">
              </div>
              <div class="form-group">
                    <textarea id="compose-textarea" class="form-control" style="height: 300px" name="message" required>
                     
                    </textarea>
              </div>
            </div>
            <!-- /.box-body -->
            <div class="box-footer">
              <div class="pull-right">
              
                <button type="submit" class="btn btn-primary"><i class="fa fa-envelope-o"></i> Send</button>
              </div>
              <a href="<?php echo e(route('messages.inbox')); ?>" class="btn btn-default"><i class="fa fa-times"></i> Discard</button>
            </div>
            <!-- /.box-footer -->
            </form>
          </div>
          <!-- /. box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->


              <div class="modal fade" id="modal-default">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Recipient</h4>
                        </div>
                        <div class="modal-body">
                            <table class="table">
                                  <thead>
                                     <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Phonenumber</th>
                                        <th>Email</th>
                                        <th>City</th>
                                        <th>Phonenumber</th>
                                     </tr>
                                  <thead>
                                  <?php if(!empty($data)): ?>
                                  <tbody>
                                     <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <tr>
                                        <td><?php echo e(++$key); ?></td>
                                        <td><?php echo e($record->firstname); ?> <?php echo e($record->lastname); ?></td>
                                        <td><?php echo e($record->email); ?></td>
                                        <td><?php echo e($record->phonenumber); ?></td>
                                        <td><?php echo e($record->location); ?></td>
                                        <td><?php echo e($record->place_of_work); ?></td>
                                      </tr>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </tbody>
                                  <?php else: ?>
                                  No record
                                  <?php endif; ?>
                            </table>
                        </div>
                      
                        </div>
                        <!-- /.modal-content -->
                    </div>
                <!-- /.modal-dialog -->
                </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zalegoa1/public_html/clientmanagementsystem/ClientMis/resources/views/messages/composeToAll.blade.php ENDPATH**/ ?>