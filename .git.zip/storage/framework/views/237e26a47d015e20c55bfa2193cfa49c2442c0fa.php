<!DOCTYPE html>
<html>
<head>
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
</style>
</head>
<body>

<table id="customers">
  <tr>
    <th>Member Id</th>
    <th>Name</th>
    <th>Membership Type</th>
    <th>Email</th>
    <th>Phonenumber</th>
    <th>City</th>
    <th>Organisation</th>
    <th>Job Title</th>
  </tr>
  <?php if(!empty($data)): ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
       
        <td><?php echo e($record->member_id); ?></td>
        <td><?php echo e($record->firstname); ?> <?php echo e($record->middlename); ?> <?php echo e($record->lastname); ?></td>
        <td><?php echo e($record->member_type); ?></td>
        <td><?php echo e($record->email); ?></td>
        <td><?php echo e($record->phonenumber); ?></td>
        <td><?php echo e($record->location); ?></td>
        <td><?php echo e($record->place_of_work); ?></td>
        <td><?php echo e($record->role); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>

</table>

</body>
</html>
<?php /**PATH /home/zalegobu/client.zalegobusiness.com/ClientMis/resources/views/reports/clientpdf.blade.php ENDPATH**/ ?>