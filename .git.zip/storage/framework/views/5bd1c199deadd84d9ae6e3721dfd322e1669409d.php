<?php $__env->startSection('content'); ?>
 <!-- Main content -->
 <?php
$clients=DB::table('clients')->get();
?>
 <section class="content">
      <div class="row">
        
        <!-- /.col -->
        <div class="col-md-12">

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title"> <a href="<?php echo e(route('messages.inbox')); ?>"> <i class="fa fa-backward"></i>Go Back</a> &nbsp; &nbsp; Compose New Message [This message will be sent only to the selected people]</h3>
            </div>
            <form method="POST" action="<?php echo e(route('messages.sendToSpecific')); ?>">
            <?php echo csrf_field(); ?>
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="form-group">
                       <label class="col-sm-2 control-label">Recipient</label>
                       <div class="col-sm-10">
                          <select class="form-control select2" multiple="multiple" data-placeholder="To" style="width: 100%;" name="phonenumbers[]">
                          <?php if(!empty($clients)): ?>
                            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($client->phonenumber); ?>"><?php echo e($client->firstname); ?> <?php echo e($client->lastname); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>
                          </select>

                        </div>
                    </div>

                    <br><br>

                    <div class="form-group">
                        <label class="col-sm-2 control-label">Subject</label>
                        <div class="col-sm-10">
                           <input class="form-control" placeholder="Subject:" name="subject">
                        </div>
                    </div>
                    <br><br>


                    <div class="form-group">
                            <label class="col-sm-2 control-label">Message</label>
                            <div class="col-sm-10">
                                <textarea  class="form-control"  name="message"> </textarea>
                            </div>
                    </div>
                  
                </div>
                <!-- /.box-body -->
                <div class="box-footer">
                  <div class="pull-right">
                  
                    <button type="submit" class="btn btn-primary"><i class="fa fa-envelope-o"></i> Send</button>
                  </div>
                  <a href="<?php echo e(route('messages.inbox')); ?>" class="btn btn-default"><i class="fa fa-times"></i> Discard</a>
                </div>
            
            </form>
            <!-- /.box-footer -->
          </div>
          <!-- /. box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ClientMis/resources/views/messages/composeSpecificGroup.blade.php ENDPATH**/ ?>