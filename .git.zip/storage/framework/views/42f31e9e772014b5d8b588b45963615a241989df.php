<?php $__env->startSection('content'); ?>
<!-- Main content -->
<section class="content">
      <div class="row">
       
        <div class="col-md-12">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Sent Mails</h3>

              <a href="<?php echo e(action('ExportManagementController@mailpdf')); ?>"><i class="fa fa-download"></i>Export Pdf</a>|
              <a href="<?php echo e(action('ExportManagementController@mailcsv')); ?>"><i class="fa fa-download">Export Csv</i></a>|
              <a href="<?php echo e(action('ExportManagementController@mailexcel')); ?>"><i class="fa fa-download">Export Excel</i></a>|

              <div class="box-tools pull-right">
                <div class="has-feedback">
                  
                </div>
              </div>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body no-padding">
              
              <div class="table-responsive mailbox-messages">
                <table class="table table-hover table-striped" id="example1">
                  <thead>
                    <tr>
                       <th>#</th>
                       <th>Email Id</th>
                       <th>Subject</th>
                       <th>Message</th>
                       <th>Date Sent</th>
                       <th>Status</th>
                       <th>Date Received</th>
                       <th>Action</th>
                       <th>Export Recipient</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php if(!empty($data)): ?>
                      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e(++$key); ?></td>
                          <td><a href="<?php echo e(url('/mails/readSentMails/'.$record->message_id)); ?>">MSG/<?php echo e($record->message_id); ?>/<?php echo e($record->year); ?></a></td>
                          <td><?php echo e($record->subject); ?></td>
                          <td><?php echo $record->message?></td>
                          <td><?php echo e($record->day); ?> <?php echo e($record->month); ?> <?php echo e($record->year); ?>: <?php echo e($record->dayTime); ?></td>
                          <td><span class="label label-success">Received</span></td>
                          <td><?php echo e($record->day); ?> <?php echo e($record->month); ?> <?php echo e($record->year); ?>: <?php echo e($record->dayTime); ?></td>
                          <td><a href="<?php echo e(url('/mails/readSentMails/'.$record->message_id)); ?>" class="btn btn-xs btn-primary">More Info</a></td>
                          <td>
                               <form  method="POST" action="<?php echo e(route('exports.ccmailpdf')); ?>">
                               <?php echo csrf_field(); ?>
                                  <input type="text" name="message_id" value="<?php echo e($record->message_id); ?>" style="display:none;">
                                  <input type="submit" class="btn btn-xs btn-primary" value="Export Recipient">
                               </form>
                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                  </tbody>
                </table>
                <!-- /.table -->
              </div>
              <!-- /.mail-box-messages -->
            </div>
            <!-- /.box-body -->
            <div class="box-footer no-padding">
              
            </div>
          </div>
          <!-- /. box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ClientMis/resources/views/mails/index.blade.php ENDPATH**/ ?>